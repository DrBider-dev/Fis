package Model;

public class Cajero extends Usuario {
    public Cajero(int id, String nombre, String tot, String credenciales) {
        super(id, nombre, tot, credenciales);
    }
}